#ifndef NINJAINC_H
#define NINJAINC_H

#ifdef VRPI10
//#include <../NinjaObjectsPi/NinjaPi.h>
#include <NinjaPi.h>
#else
#include <../Sensors/Sensors.h>
#include <../NinjaObjects/NinjaObjects.h>
#endif

#endif